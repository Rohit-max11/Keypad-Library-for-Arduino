/*Created by Rohit Jacob
  on 3rd July

###########################

/*This library is distributed
  to the general public and 
  is allowed to be to modified */

#ifndef _KEYPAD_H_
#define _KEYPAD_H_


#include <Arduino.h>              //For including functions like digitalRead or write

class keypad {
	int pin_hold[8], col, row, pro_start;
	char sym_table[4][4];

	void detect_press();
	char get_key(int row, int col);
	void init_key();
	char read_key();

public:
        int invoke_start();
	keypad(int arr[8], char sym[4][4]); 
	void reset();
	char give_key(keypad key1);      //This function scans for a key press and returns the key
}; 


#endif
