# Installation #
In arduino IDE
Open sketch>Include Library>Add zip lib.. and then add this zip from wherever you have downloaded it into.


-------------------------------------------------------------------------------------------------------------------
This library is created by Rohit Jacob (A freelance newbie dev ;) )

-------------------------------------------------------------------------------------------------------------------
This library works for any keypad that has a max rows and cols upto 4

-------------------------------------------------------------------------------------------------------------------

Extract the zip before using the example files.