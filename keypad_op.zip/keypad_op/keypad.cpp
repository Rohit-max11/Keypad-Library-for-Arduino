#include "keypad.h"
#include <Arduino.h>

void keypad::detect_press()  //Function which clocks very fast to detect press
{
    for (int i = 4; i < 8; i++)
        if (!digitalRead(pin_hold[i]))
        {
            col = i;
            break;
        }
    if (col != -1)
    {
        for (int i = 0; i < 4; i++)
        {
            digitalWrite(pin_hold[i], HIGH);
            if (digitalRead(pin_hold[col]))
            {
                row = i;
                break;
            }
            else
                digitalWrite(pin_hold[i], LOW);
        }
    }
    delay(150);              //Added delay to filter debounce
}
char keypad::get_key(int row,int col)
{
    return sym_table[row - 1][col];
}
void keypad::init_key()     
{
    for (int i = 0; i < 4; i++)
        digitalWrite(pin_hold[i], LOW);
}
char keypad::read_key()         
{
    char ch;
    for (;;)
    {
        init_key();
        detect_press();
        if (row != -1 && col != -1)
        {
            ch = get_key(row, col);
            return ch;
        }

    }
}
int keypad::invoke_start()  //Use this function to get rid of initial garbage data
{                           //Refer to the lcd_interface example for more details
    if (pro_start)
        return 0;
    else
    {
        pro_start = 1;
        return 1;


    }


}

void keypad::reset()
{
    row = -1;
    col = -1;
    pinMode(pin_hold[0], OUTPUT);
    pinMode(pin_hold[1], OUTPUT);
    pinMode(pin_hold[2], OUTPUT);
    pinMode(pin_hold[3], OUTPUT);
    pinMode(pin_hold[4], INPUT_PULLUP);
    pinMode(pin_hold[5], INPUT_PULLUP);
    pinMode(pin_hold[6], INPUT_PULLUP);
    pinMode(pin_hold[7], INPUT_PULLUP);
}
keypad::keypad(int arr[8], char sym[4][4]) {

    pro_start = 0;
    reset();
    for (int i = 0; i < 8; i++)
        pin_hold[i] = arr[i];
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 4; j++)
            sym_table[i][j] = sym[i][j];
}
char keypad::give_key(keypad key1)       //This is the function to be called to get the user input key
{
    char ch;
    init_key();
    ch = key1.read_key();
    key1.reset();
    return ch;

}


